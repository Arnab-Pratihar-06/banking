package com.cg.banking.daoservices;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transactions;

public interface TransactionsDAO {
	Transactions save(Account accountNo,Transactions transaction);
	boolean update(Account  accountNo,Transactions  transaction);
	Transactions findOne(Account accountNo,int transactionId);
	List<Transactions>findAll(long accountNo);
}
